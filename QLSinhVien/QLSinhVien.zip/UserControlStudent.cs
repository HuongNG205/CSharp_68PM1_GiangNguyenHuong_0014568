﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSinhVien
{
    public partial class UserControlStudent : UserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public UserControlStudent()
        {
            InitializeComponent();
        }

        private void UserControlStudent_Load(object sender, EventArgs e)
        {
            List<SinhVien> svList = db.SinhViens.ToList();
            table_Student.DataSource = svList;

            table_Student.Columns["MaSV"].HeaderText = "Mã sinh viên";
            table_Student.Columns["HoTen"].HeaderText = "Họ tên";
            table_Student.Columns["Gender"].HeaderText = "Giới tính";
            table_Student.Columns["Birth"].HeaderText = "Ngày sinh";
            table_Student.Columns["MaLop"].HeaderText = "Lớp";

            table_Student.Columns["Birth"].DefaultCellStyle.Format = "dd/MM/yyyy";
        }

    }
}
