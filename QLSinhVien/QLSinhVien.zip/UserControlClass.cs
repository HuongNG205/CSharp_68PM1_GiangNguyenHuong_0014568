﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSinhVien
{
    public partial class UserControlClass : UserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public UserControlClass()
        {
            InitializeComponent();
        }

        private void UserControlClass_Load(object sender, EventArgs e)
        {
            List<LopHoc> clList = db.LopHocs.ToList();
            table_Class.DataSource = clList;

            table_Class.Columns["id"].HeaderText = "Mã ID";
            table_Class.Columns["MaLop"].HeaderText = "Mã lớp";
            table_Class.Columns["TenLop"].HeaderText = "Tên lớp";
            table_Class.Columns["Note"].HeaderText = "Ghi chú";
        }
    }
}
